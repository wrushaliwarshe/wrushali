package com.flp.fms.view;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class BootClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int option;
		UserInteraction userInteraction=new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();
		String choice=null;
		
		do{
		
			menuSelection();
			System.out.println("Enter your option:[1-6]");
			option=sc.nextInt();
			switch(option){
				case 1:
					Film film=userInteraction.addFilm(filmService.getLanguages(), filmService.getCategories(), actorService.getActors());
					filmService.addFilm(film);
					break;
				case 2://Modify Film
					int filmId = userInteraction.readFilmId();
					film = filmService.searchFilm(filmId);
					if(film==null)
						userInteraction.printFilm(film);
					else{
						
						userInteraction.printFilm(film);
						film = userInteraction.addFilm(filmService.getLanguages(), filmService.getCategories(),
								actorService.getActors());
						film.setFilm_Id(filmId);
						filmService.updateFilm(film);       
					}
						
					
					break;
					
				case 3://Remove Film
					System.out.println("\t1.remove by id\n\t2.remove by title\n\t3.remove by rating\n"
							+ "\t4.remove film by actor\n");
					System.out.println("enter your option");
					int opt=sc.nextInt();
					switch (opt) {
					
						case 1:
							filmService.removeFilm(userInteraction.readFilmId());
							break;
							
						case 2:
							filmService.removeFilm(userInteraction.readTitle());
							break;
							
						case 3:
							filmService.removeFilmByRating(userInteraction.readRating());
							break;
							
						case 4:
							filmService.removeFilm(userInteraction.addActor(actorService.getActors()));
							break;

					default:
						filmService.removeFilmByRating(userInteraction.readRating());
						break;
					}
					
					break;
					
				case 4://Search film
					System.out.println("\t1.search by Id\n\t2.search by Title\n\t3.search by Rating\n"
							+ "\t4.search by Actor\n\t5.search by Language");
					System.out.println("enter your option");
					int op=sc.nextInt();
					
					switch(op){
					
						case 1:
							film = filmService.searchFilm(userInteraction.readFilmId());
							userInteraction.printFilm(film);
							break;
							
						case 2:
							film = filmService.searchFilm(userInteraction.readTitle());
							userInteraction.printFilm(film);
							break;
							
						case 3:
							List<Film> films = filmService.searchFilmByRating(userInteraction.readRating());
							userInteraction.getAllFilm(films);;
							break;
							
						case 4:
							List<Film> selectedFilms = filmService.searchFilm(userInteraction.addActor(actorService.getActors()));
							userInteraction.getAllFilm(selectedFilms);
							break;
							
						case 5:
							List<Language> allLanguages = filmService.getLanguages();
							List<Film> selectedFilms2 = filmService.searchFilm(userInteraction.addLanguage(allLanguages));
							userInteraction.getAllFilm(selectedFilms2);
							break;
							
						default:
							System.out.println("wrong option entered");
					}
					break;
				case 5://Print film Repository
					Map<Integer, Film>  film_lst1= filmService.getAllFilms();
					Collection<Film> lst1=film_lst1.values();
					userInteraction.getAllFilm(lst1);
					break;
				case 6://Exit
					System.exit(0);
			}
		System.out.println("Wish to do more Operation?[y|n]");
		choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
	}

	public static void menuSelection(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}
	
	
}
