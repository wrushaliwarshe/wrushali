package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmService;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class UpdateFilmServlet1
 */
public class UpdateFilmServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FilmService filmservice=new FilmServiceImpl();
		List<Film> film=filmservice.getAllFilms();
		PrintWriter out=response.getWriter();
		
	

		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		
		
		out.println("<body>"
		
				+ "<h2 align='center'>List Of Films</h2>"
				+ "<table border=2px>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Languages</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Features</th>"
				+ "<th>Actors</th>"
				+ "<th>Category</th>"
				+ "<th>Update</th>"
				+ "</tr>");
		for(Film film1:film){
			List<Language> languages=film1.getLanguages();
			
			String langs="";
			for(Language lang:languages)
			{
				langs=langs+lang.getLanguage_Name()+",";
			}
			
			Set<Actor> actors=film1.getActors();
			String actors1="";
			for(Actor actor:actors)
			{
				actors1=actors1+actor.getActor_FirstName()+" "+actor.getActor_LastName()+",";
			}
			out.println("<tr>");
			out.println("<td>"+film1.getFilm_Id()+"</td>");
			out.println("<td>"+film1.getTitle()+"</td>");
			out.println("<td>"+film1.getDescription()+"</td>");
			out.println("<td>"+film1.getReleaseYear()+"</td>");
			out.println("<td>"+film1.getOriginalLanguage().getLanguage_Name()+"</td>");
			out.println("<td>"+langs.substring(0, (langs.length()-1))+"</td>");
			out.println("<td>"+film1.getRentalDuration()+"</td>");
			out.println("<td>"+film1.getLength()+"</td>");
			out.println("<td>"+film1.getReplacementCost()+"</td>");
			out.println("<td>"+film1.getRatings()+"</td>");
			out.println("<td>"+film1.getSpecialFeatures()+"</td>");
			out.println("<td>"+actors1.substring(0, (actors1.length()-1))+"</td>");
			out.println("<td>"+film1.getCategory().getCategory_Name()+"</td>");
			out.print("<td><a href='UpdateFilmServlet2?id="+film1.getFilm_Id()+"'><h5 style='color:pink;'>Update</h5></a></td>");
			out.println("</tr>");
		}
			out.println("</table></body>");
	}
	
	
	
	
	}


