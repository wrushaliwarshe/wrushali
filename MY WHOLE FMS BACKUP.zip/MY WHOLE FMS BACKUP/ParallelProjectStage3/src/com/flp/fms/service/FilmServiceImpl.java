package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.dao.*;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements FilmService{
	FilmDao filmdao=new FilmDaoImpl();
	
	//-----Getting All Languages---------//
	public ArrayList<Language> getLanguages(){
		return filmdao.getLanguages();
	}
	
	//-----Getting All Actors-----------//
	public ArrayList<Actor> getActors(){
		return filmdao.getActors();
	}
	
	//-------Getting All Categories------//
	public ArrayList<Category> getCategories(){
		return filmdao.getCategories();
	}
	
	//--------Calling Save Film of DAO-------------//
	public Boolean saveFilm(Film film){
		return filmdao.saveFilm(film);
	}
	
	//----------Getting All Films--------------//
	public ArrayList<Film> getAllFilms(){
		return filmdao.getAllFilms();
	}
	
	//----------Deleting Film---------------//
	public boolean deleteFilm(int filmid){
		return filmdao.deleteFilm(filmid);
	}
	
	//--------Searching Film by All Fields----//
	public List<Film> searchFilm(Film film ){
		return filmdao.searchFilm(film);
	}

	//---------Updating Film----------------//
	@Override
	public int updateFilm(int id,Film film){
		return filmdao.updateFilm(id, film);
	}

	//--------Searching film by Id----------//
	public Film getSearchFilmByID(int id) {
		return filmdao.getSearchFilmByID(id);
	}


	
	
	
	
}
