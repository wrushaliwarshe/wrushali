package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;

public class ActorDaoImplForList implements IActorDao{

//---------Connection Method--------------//
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fmsdbstage2","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	}	
	

//----------Getting List Of Actors ----------//
	@Override
	public Set<Actor> getActors() {
		
		Set<Actor> actors=new HashSet<>();
		
		   Connection con=getConnection();
			
			String sql="select actorID,firstName,lastname from actor";
			
			try {
				Statement stmt=con.createStatement();
				
				ResultSet rs=stmt.executeQuery(sql);
				
				while(rs.next()){
					
					actors.add(new Actor(rs.getInt(1), rs.getString(2),rs.getString(3)));
					
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
	
		return actors;
	}

}
