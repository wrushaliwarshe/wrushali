package org.capgemini.spring;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	
	
@RequestMapping("/hello")	
public ModelAndView SayHello()
{
	String message="hi this is spring MVC";
	return new ModelAndView("helloPage","msg",message);
}
}
