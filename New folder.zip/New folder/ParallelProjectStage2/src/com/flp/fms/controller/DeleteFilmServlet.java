package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Film;
import com.flp.fms.service.FilmService;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class DeleteFilmServlet
 */
public class DeleteFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		FilmService filmservice=new FilmServiceImpl();
		ArrayList<Film> films=filmservice.getAllFilms();
		out.println("<html>");
		out.println("<head>Delete Film</head>"
				+ "<body>"
				+ "<table>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Date</th>"
				+"<th> Original language</th>"
				+ "<th>Rental Duration</th>"
				+"<th>Length</th>"
				+ "<th>Replacement cost</th>"
				+"<th>Ratings</th>"
				+"<th>Special Feature</th>"
				+"<th>Category</th>"
				+"<th>Languages</th>"
				+"<th>Actors</th>"
				+ "<th></th>"
				+ "</tr>"); 
		
		
		for(Film film:films){
			out.println("<tr id=''>");
			out.println("<td>"+film.getFilm_Id()+"</td>");
			out.println("<td>"+film.getTitle()+"</td>");
			out.println("<td>"+film.getDescription()+"</td>");
			out.println("<td>"+film.getReleaseYear()+"</td>");
			out.println("<td>"+film.getOriginalLanguage()+"</td>");
			out.println("<td>"+film.getRentalDuration()+"</td>");
			out.println("<td>"+film.getLength()+"</td>");
			out.println("<td>"+film.getReplacementCost()+"</td>");
			out.println("<td>"+film.getRatings()+"</td>");
			out.println("<td>"+film.getSpecialFeatures()+"</td>");
			out.println("<td>"+film.getCategory()+"</td>");
			out.println("<td>"+film.getLanguages()+"</td>");
			out.println("<td>"+film.getActors()+"</td>");
			out.println("<td><a href='DeleteServlet?filmid="+film.getFilm_Id()+"'>Delete</a></td>");
			out.println("</tr>");
			
		}
			out.println("</table></body>");

			out.println("</html>");
		
	}


}
