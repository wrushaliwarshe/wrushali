package com.flp.fms.dao;

public class ActorDaoImpl implements ActorDao{

}
