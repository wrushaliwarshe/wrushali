package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.*;

public interface FilmDao {
public void saveFilm(Film film);
public ArrayList<Film> getAllFilms();
public List<Film> searchFilm( Film film);
public ArrayList<Language> getLanguages();
public ArrayList<Actor> getActors();
public ArrayList<Category> getCategories();
public boolean deleteFilm(int filmid);
public int updateFilm(int id,Film film);
public Film getSearchFilmByID(int id);


	

}
