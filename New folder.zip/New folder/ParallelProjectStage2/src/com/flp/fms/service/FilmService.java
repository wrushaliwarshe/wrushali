package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface FilmService {
	public ArrayList<Language> getLanguages();
	public ArrayList<Actor> getActors();
	public ArrayList<Category> getCategories();
	public void saveFilm(Film film);

	public ArrayList<Film> getAllFilms();
	public boolean deleteFilm(int filmid);
	public List<Film> searchFilm(Film film);
	public int updateFilm(int id,Film film);
	public Film getSearchFilmByID(int id);
	
}
