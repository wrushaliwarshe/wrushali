package com.flp.fms.service;

public interface ActorService {

}
