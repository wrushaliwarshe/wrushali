package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.dao.*;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements FilmService{
	FilmDao filmdao=new FilmDaoImpl();
	
	public ArrayList<Language> getLanguages(){
		return filmdao.getLanguages();
	}
	
	public ArrayList<Actor> getActors(){
		return filmdao.getActors();
	}
	
	public ArrayList<Category> getCategories(){
		return filmdao.getCategories();
	}
	public void saveFilm(Film film){
		filmdao.saveFilm(film);
	}
	
	
	public ArrayList<Film> getAllFilms(){
		return filmdao.getAllFilms();
	}
	
	public boolean deleteFilm(int filmid){
		return filmdao.deleteFilm(filmid);
	}
	
	public List<Film> searchFilm(Film film ){
		return filmdao.searchFilm(film);
	}

	@Override
	public int updateFilm(int id,Film film){
		return filmdao.updateFilm(id, film);
		
	}


	public Film getSearchFilmByID(int id) {
		
		return filmdao.getSearchFilmByID(id);
	}


	
	
	
	
}
