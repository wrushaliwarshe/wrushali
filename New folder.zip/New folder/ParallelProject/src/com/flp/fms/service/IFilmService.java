package com.flp.fms.service;
import com.flp.fms.domain.*;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface IFilmService {
	public List<Language> getLanguages();
	public List<Category> getCategories();
	public void addFilm(Film film);
	public Map<Integer, Film> getAllFilms();
	//public void searchFilmById(Collection<Film> lst);
}
