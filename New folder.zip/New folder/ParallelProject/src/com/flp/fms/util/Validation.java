package com.flp.fms.util;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.flp.fms.domain.Language;

public class Validation {
	
//---------------------------------------------------------------------
//VALIDATION FOR TITLE	
	public static boolean isValidTitle(String title){
		return title.matches("[A-Za-z0-9.,! ]+");
	}
	
//---------------------------------------------------------------------
//VALIDATION FOR RATING	
	public static boolean isValidRating(int ratings){
		boolean rate_flag=false;
		if(ratings>0 &&ratings<=5)
			rate_flag=true;
		
		return rate_flag;
	}
	
//---------------------------------------------------------------------
//VALIDATION FOR REPLACEMENT COST	
	public static boolean isValidReplacementCost(double replacementcost)
	{
		if(replacementcost>=0)
			return true;
		else return false;
	}
	
//----------------------------------------------------------------------
//VALIDATION FOR DATE
public static boolean isValidDate(String myDate){
	return myDate.matches("[0123][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][890]\\d{2}");
}

//----------------------------------------------------------------------
//VALIDATION FOR DUPLICATE LANGUAGE

public static boolean checkDuplicateLanguage(List<Language> languages,Language language){
	boolean flag=false;
	
	Iterator<Language> it= languages.iterator();
	if(languages.isEmpty())
	{
		flag=false;
	}else{
		while(it.hasNext()){
			Language language2=it.next();
			if(language.equals(language2))
			{
				flag=true;
				break;
			}
		}
	}
	return flag;
}

//--------------------------------------------------------------------
//VALIDATION FOR LENGTH
public static boolean isValidLength(int length){
	
boolean lflag;
if(length>0&&length<1000)
{
	lflag=true;
}
else 
	lflag=false;
	return lflag;
}}
	



