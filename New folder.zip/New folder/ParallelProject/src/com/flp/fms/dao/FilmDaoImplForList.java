package com.flp.fms.dao;
import com.flp.fms.domain.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class FilmDaoImplForList implements IFilmDao  {
	private Map<Integer, Film> film_Repository=new HashMap<>();

//--------------------------------------------------------------------	
//overriding getlanguages from IfilmDao
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marathi"));
		languages.add(new Language(5, "Kananta"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		
		
		return languages;
	}
	
//-----------------------------------------------------------------------
//Overriding getCategories from IfilmDAO	
	public List<Category> getCategories() {
		List<Category> categories=new ArrayList<>();
		categories.add(new Category(1, "Comedy"));
		categories.add(new Category(2, "Action"));
		categories.add(new Category(3, "Thriller"));
		categories.add(new Category(4, "Romantic"));
		categories.add(new Category(5, "Horror"));
		categories.add(new Category(6, "Suspense"));
		
		
		
		return categories;
}

//-----------------------------------------------------------------------
//CURD Operation
	@Override
	public void addFilm(Film film){
		film_Repository.put(film.getFilm_Id(), film);
		
	}

//----------------------------------------------------------------------
//For get all film option
	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return film_Repository;
	}
	
//--------------------Search Film by Id-----------------------------------------
public void searchFilmById(Collection<Film> lst){
		Boolean flag=false;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Film Id to be searched");
		int searchId=sc.nextInt();
		for(Film film:lst){
			
		if(film.getFilm_Id()==searchId)
		{
			
			String languages="";
		for(Language language:film.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			System.out.println("filmID\tfilmtitle\trelease year"
			+ "\tdescription\tspecialFeatures\tRentalDuration\tReplacementCost"
			+ "\tratings\tlaguages");
			System.out.println(film.getFilm_Id() + "\t" +
					film.getTitle() + "\t"+
					film.getReleaseYear() + "\t"+film.getDescription()+
					film.getSpecialFeatures()+ "\t"+film.getRentalDuration()+"\t"+
					film.getReplacementCost()+"\t"+
					film.getRatings()+"\t"+languages);
			
	}else{
		System.out.println("not found");
		break;}
		}}
}