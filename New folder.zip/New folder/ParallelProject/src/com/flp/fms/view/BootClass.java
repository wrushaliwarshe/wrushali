package com.flp.fms.view;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.*;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class BootClass {


		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			int option;
			int searchId;
			UserInteraction userInteraction=new UserInteraction();
			IFilmService filmService=new FilmServiceImpl();
			IActorService actorService=new ActorServiceImpl();
			String choice;
			
			do{
				menuSelection();
			System.out.println("Enter your option:[1-6]");
			option=sc.nextInt();
			switch(option){
				case 1:
					Film film=userInteraction.addFilm(filmService.getLanguages(),filmService.getCategories(),actorService.getActors());
					
					
					filmService.addFilm(film);
					System.out.println(film);
					break;
				case 2:
					break;
				case 3:
					break;
				case 4:
					Map<Integer, Film>  film_map= filmService.getAllFilms();
					Collection<Film> map=film_map.values();
					searchmenu();
					System.out.println("Enter your choice");
					int search_choice;
					search_choice=sc.nextInt();
					switch(search_choice)
					{
					case 1:
						userInteraction.searchFilmById(map);
						break;
					case 2:
						userInteraction.searchFilmByTilte(map);
						break;
					case 3:
						userInteraction.searchFilmByRatings(map);	
						break;
					}
					
					
					
					break;
				case 5:
					Map<Integer, Film>  film_lst= filmService.getAllFilms();
					Collection<Film> lst=film_lst.values();
					userInteraction.getAllFilm(lst);
					
				
					break;
				case 6:
					System.exit(0);
			}
			System.out.println("Wish to do more Operation?[y|n]");
			choice=sc.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			
		}
		
//-----------------------------------------------------
//MENU SELECTION METHOD		
		public static void menuSelection(){
			System.out.println("1.Add Film");
			System.out.println("2.Modify Film");
			System.out.println("3.Remove Film");
			System.out.println("4.Search Film");
			System.out.println("5.GetAll Film");
			System.out.println("6.Exit");
			
		}
		
		public static void searchmenu(){
			System.out.println("1.Search Film By FilmId");
			System.out.println("2.Search Film By FilmTitle");
			System.out.println("3.Search Film By FilmRatings");
			System.out.println("4.Search Film By FilmActor");
			System.out.println("5.Search Film By filmLanguage");
			System.out.println("6.Exit");
			
}}

	


