package com.flp.fms.view;
import java.lang.*;
import java.util.Date;
import java.util.*;
import java.util.List;
import java.util.Scanner;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validation;

public class UserInteraction {

Scanner sc=new Scanner(System.in);


public String disString;
public int ratings;
double replacementcost;
String sfString;



//Return fully qualified film object
		public Film addFilm(List<Language> languages,List<Category> categories,Set<Actor>  actors){
		Film film=new Film();
		boolean flag=true;
		
//Get Title and validate it
		String title=null;
		do{
		System.out.println("Enter Film Title");
		title=sc.nextLine();
		flag=Validation.isValidTitle(title);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setTitle(title);
		
		
		String releaseDate;
		boolean date_flag=false;
		Date release_Date=null;
		String rentalDuration;
		Date rental_Duration=null;
		boolean rent_flag=false;
		int length;

//release date
		do{
			
			do{
				System.out.println("Enter Release Date:");
				releaseDate=sc.next();
				flag=Validation.isValidDate(releaseDate);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			Date today=new Date();
			release_Date=new Date(releaseDate);
			if(release_Date.before(today)|| release_Date.equals(today))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(!date_flag);
		film.setReleaseYear(release_Date);
		
//Rental duration
		do{
			
		do{
				System.out.println("Enter Rental Duration:");
				rentalDuration=sc.next();
				rent_flag=Validation.isValidDate(rentalDuration);
				if(!rent_flag)
					System.out.println("Please enter date in this Format(dd-MM-yyyy)!");
			}while(!rent_flag);
			
			Date today=new Date();
			rental_Duration=new Date(rentalDuration);
			if(rental_Duration.after(release_Date))
				rent_flag=false;
		
			if(rent_flag)
				System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(rent_flag);
		film.setRentalDuration(rental_Duration);
		
//Length validation
		boolean lflag;
		do{
			System.out.println("Enter film length in min");
			lflag=true;
		length=sc.nextInt();
		
		lflag=Validation.isValidLength(length); 
		if(lflag)
		{
		film.setLength(length);
		}
		else 
		System.out.println("Invaid length!Enter length between 0 to 1000 minutes");
		}while(!lflag);
		
//Description
		System.out.println("Enter the description");
		disString=sc.next();
		film.setDescription(disString);
		
		
//Special Features
				System.out.println("Enter the Special Features");
				sfString=sc.next();
				film.setSpecialFeatures(sfString);
				
				
//get and set the replacement cost
				do{
				System.out.println("Enter Replacement cost");
				replacementcost=sc.nextDouble();
				flag=Validation.isValidReplacementCost(replacementcost);
				if(flag==false)
					System.out.println("Please enter a valid cost");
				}while(!flag);
				film.setReplacementCost(replacementcost);
				
				
//get and set the rating
				do{
					System.out.println("Enter ratings[1-5]");
					ratings=sc.nextInt();
					flag=Validation.isValidRating(ratings);
					if(flag==false)
					{
						System.out.println("Invalid rating!!!rating in between 1-5");
					}
					}while(!flag);
				film.setRatings(ratings);
//Choose Language
		System.out.println("Choose Original Language");
		Language language= selectLanguage(languages);
		film.setOriginalLanguage(language);
		
	
//Add all languages
				List<Language> languages2=new ArrayList<>();
				String choice;
				boolean flag_langs;
				do{
					System.out.println("Choose All Languages for the Film:");
					Language language1= selectLanguage(languages);
					
					
					flag_langs=Validation.checkDuplicateLanguage(languages2, language1);
					if(!flag_langs)
						languages2.add(language1);
					else
						System.out.println("Language already Exists. Please try other languages!");
					
					
					System.out.println("Wish to add More Languages?[y|n]");
					choice=sc.next();
				}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
				film.setLanguages(languages2);
				
//Add all Actors
				Set<Actor> actors2=new HashSet<>();
				Actor actor;
				String actorchoice;
				boolean flag_actor;
				do{
					System.out.println("Choose All Actors for the Film:");
					actor= selectactors(actors);
					actors2.add(actor);
					
					
					System.out.println("Wish to add More Languages?[y|n]");
					choice=sc.next();
				}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
				film.setActors(actors2);
				
				//Choose Category
				System.out.println("Choose Category");
				Category category= selectCategory(categories);
				film.setCategory(category);
				
				
				
				
			
				
				return film;
}
		
//Choose Valid Language Object from the list of Languages
	public Language selectLanguage(List<Language>  languages){
			
	Language sel_language=null;
	boolean flag;
	do{	

//Print Langauge Details
	for(Language language:languages)
	System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
				
	System.out.println("Choose the Language:");
	int option=sc.nextInt();
				
	flag=false;
				
//Check the Language Object
				for(Language language: languages)
				{
					if(option==language.getLanguage_Id())
					{
						sel_language=language;
						flag=true;
						break;
					}
				}
				
				//Print Error Message
				if(!flag)
					System.out.println("Please select valid Language Id");
			}while(!flag);	
			
			return sel_language;
	}

//Choose Valid Actor Object from the list of Actor
	public Actor selectactors(Set<Actor>  actors){
			
	Actor sel_actor=null;
	boolean flag;
	do{	

//Print Actor Details
	for(Actor actor:actors)
	System.out.println(actor.getActor_Id() + "\t" + actor.getActor_FirstName()+"\t"+actor.getActor_LastName());
				
	System.out.println("Choose the actors:");
	int option=sc.nextInt();
				
	flag=false;
				
//Check the Actor Object
				for(Actor actor: actors)
				{
					if(option==actor.getActor_Id())
					{
						sel_actor=actor;
						flag=true;
						break;
					}
				}
				
				//Print Error Message
				if(!flag)
					System.out.println("Please select valid actor Id");
			}while(!flag);	
			
			return sel_actor;
	}
//Category selection
		
    public Category selectCategory(List<Category>  categories){
					
	Category sel_category=null;
	boolean flag;
	do{	
//Print Category Details
	for(Category category:categories)
	System.out.println(category.getCategory_Id() + "\t" + category.getCategory_Name());
	System.out.println("Choose the Category:");
	int option=sc.nextInt();
						
	flag=false;
						
//Check the Category Object
	for(Category language: categories)
	 {
		if(option==language.getCategory_Id())
		{
			sel_category=language;
			flag=true;
			break;
			}
			}
						
//Print Error Message for Category
	if(!flag)
	System.out.println("Please select valid Category Id");
	}while(!flag);	
					
	return sel_category;
	}


	public void getAllFilm(Collection<Film> lst) {
		
		
		
		for(Film film:lst){
			String languages="";
			for(Language language:film.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			System.out.println("filmID\tfilmtitle\trelease year"
			+ "\tdescription\tspecialFeatures\tRentalDuration\tReplacementCost"
			+ "\tratings\tlaguages");
			System.out.println(film.getFilm_Id() + "\t" +
					film.getTitle() + "\t"+
					film.getReleaseYear() + "\t"+film.getDescription()+
					film.getSpecialFeatures()+ "\t"+film.getRentalDuration()+"\t"+
					film.getReplacementCost()+"\t"+
					film.getRatings()+"\t"+languages);
			}
}
	
//------------------Method to search film by filmId---------------------------//	
public static void searchFilmById(Collection<Film> lst){
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter the Film Id to be searched");
	int searchId=sc.nextInt();

	
	for(Film film:lst){
		
		
	if(film.getFilm_Id()==searchId)
	{
		
		String languages="";
	for(Language language:film.getLanguages())
			languages=languages+language.getLanguage_Name()+",";
		System.out.println("filmID\tfilmtitle\trelease year"
		+ "\tdescription\tspecialFeatures\tRentalDuration\tReplacementCost"
		+ "\tratings\tlaguages");
		System.out.println(film.getFilm_Id() + "\t" +
				film.getTitle() + "\t"+
				film.getReleaseYear() + "\t"+film.getDescription()+
				film.getSpecialFeatures()+ "\t"+film.getRentalDuration()+"\t"+
				film.getReplacementCost()+"\t"+
				film.getRatings()+"\t"+languages);

	}else{
	System.out.println("Film not found");
	break;}
	}
	}
	
//-----------Method to search film by filmTitle-------------------------//
	public static void searchFilmByTilte(Collection<Film> lst){
		//Boolean flag=false;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Film Title to be searched");
		String searchTilte=sc.next();
	
		
		for(Film film:lst){
			
			
		if(film.getTitle().equals(searchTilte))
		{
			
			String languages="";
		for(Language language:film.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			System.out.println("filmID\tfilmtitle\trelease year"
			+ "\tdescription\tspecialFeatures\tRentalDuration\tReplacementCost"
			+ "\tratings\tlaguages");
			System.out.println(film.getFilm_Id() + "\t" +
					film.getTitle() + "\t"+
					film.getReleaseYear() + "\t"+film.getDescription()+
					film.getSpecialFeatures()+ "\t"+film.getRentalDuration()+"\t"+
					film.getReplacementCost()+"\t"+
					film.getRatings()+"\t"+languages);
	
		}else{
		System.out.println("Film not found");
		break;}
		}}
	


	//------------------Method to search film by filmRatings--------------------------//	
	public static void searchFilmByRatings(Collection<Film> lst){
		Boolean flag=false;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Film Ratings to be searched");
		int searchRatings=sc.nextInt();
		
		for(Film film:lst){
			
		if(film.getRatings()==searchRatings)
		{
			String languages="";
		for(Language language:film.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			System.out.println("filmID\tfilmtitle\trelease year"
			+ "\tdescription\tspecialFeatures\tRentalDuration\tReplacementCost"
			+ "\tratings\tlaguages");
			System.out.println(film.getFilm_Id() + "\t" +
					film.getTitle() + "\t"+
					film.getReleaseYear() + "\t"+film.getDescription()+
					film.getSpecialFeatures()+ "\t"+film.getRentalDuration()+"\t"+
					film.getReplacementCost()+"\t"+
					film.getRatings()+"\t"+languages);
			flag=true;
	}else{
		System.out.println("not found");
	break;}

		}
		
}

//-----------Method to search film by filmCategory-------------------------//
	public static void searchFilmByCategory(Collection<Film> lst){
		//Boolean flag=false;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Film Category to be searched");
		String searchCategory=sc.next();
		
		for(Film film:lst){
			
			
		if(film.getCategory().equals(searchCategory))
		{
			
			String languages="";
		for(Language language:film.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			System.out.println("filmID\tfilmtitle\trelease year"
			+ "\tdescription\tspecialFeatures\tRentalDuration\tReplacementCost"
			+ "\tratings\tlaguages");
			System.out.println(film.getFilm_Id() + "\t" +
					film.getTitle() + "\t"+
					film.getReleaseYear() + "\t"+film.getDescription()+
					film.getSpecialFeatures()+ "\t"+film.getRentalDuration()+"\t"+
					film.getReplacementCost()+"\t"+
					film.getRatings()+"\t"+languages);
	
		}else{
		System.out.println("Film not found");
		break;}
		}}



//Modify Film
public Film modifyFilm(Collection<Film> lst,int choice)
{
	int flag = 0;
	switch(choice)
	{
	case 1:
			System.out.println("Enter the Rating");
			int rate=sc.nextInt();
			for(Film film:lst)
			{
				if(film.getRatings()==rate)
				{
					flag=1;
					System.out.println("Film Id \t  Film Actors \t \t  Original Language \t Languages \t \t Description \t \t Special Features \t Category \t Release Date \t \t  Rental Date \t \tReplacement Cost \t Duration \t Ratings");
					flag=1;	
					String languages="";
					for(Language language:film.getLanguages())
						languages=languages+language.getLanguage_Name()+",";
					String actors="";
					for(Actor actor:film.getActors())
						actors=actors+actor.getActor_FirstName()+actor.getActor_LastName()+",";
					System.out.println(film.getFilm_Id() + "\t" +film.getTitle() + "\t"+actors + "\t"+film.getOriginalLanguage()+"\t"+	languages+"\t"+	film.getDescription()+"\t"+film.getSpecialFeatures()+"\t"+film.getCategory()+"\t"+film.getReleaseYear()+"\t"+film.getRentalDuration()+"\t"+film.getReplacementCost()+"\t"+film.getLength()+"\t"+film.getRatings());				
					return film;
					
				}
			}
			if(flag==0)
			{
				System.out.println("Film not found");
			}
			break;
	case 2:
		System.out.println("Enter Film Name");
		String film=sc.next();
		for(Film film1:lst)
		{
		if(film1.getTitle().equals(film))
		{
			flag=1;
			System.out.println("Film Id \t  Film Actors \t \t  Original Language \t Languages \t \t Description \t \t Special Features \t Category \t Release Date \t \t  Rental Date \t \tReplacement Cost \t Duration \t Ratings");
			flag=1;	
			String languages="";
			for(Language language:film1.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			String actors="";
			for(Actor actor:film1.getActors())
				actors=actors+actor.getActor_FirstName()+actor.getActor_LastName()+",";
			System.out.println(film1.getFilm_Id() + "\t" +film1.getTitle() + "\t"+actors + "\t"+film1.getOriginalLanguage()+"\t"+	languages+"\t"+	film1.getDescription()+"\t"+film1.getSpecialFeatures()+"\t"+film1.getCategory()+"\t"+film1.getReleaseYear()+"\t"+film1.getRentalDuration()+"\t"+film1.getReplacementCost()+"\t"+film1.getLength()+"\t"+film1.getRatings());				
			return film1;
		}
		}
	if(flag==0)
	{
		System.out.println("Film not found");
	}
	break;
	case 3:
		System.out.println("Enter Release Date");
		String date=sc.next();
		Date dt=new Date(date);
		for(Film film1:lst)
		{
		if(film1.getReleaseYear().equals(dt))
		{
			flag=1;
			System.out.println("Film Id \t  Film Actors \t \t  Original Language \t Languages \t \t Description \t \t Special Features \t Category \t Release Date \t \t  Rental Date \t \tReplacement Cost \t Duration \t Ratings");
			flag=1;	
			String languages="";
			for(Language language:film1.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			String actors="";
			for(Actor actor:film1.getActors())
				actors=actors+actor.getActor_FirstName()+actor.getActor_LastName()+",";
			System.out.println(film1.getFilm_Id() + "\t" +film1.getTitle() + "\t"+actors + "\t"+film1.getOriginalLanguage()+"\t"+	languages+"\t"+	film1.getDescription()+"\t"+film1.getSpecialFeatures()+"\t"+film1.getCategory()+"\t"+film1.getReleaseYear()+"\t"+film1.getRentalDuration()+"\t"+film1.getReplacementCost()+"\t"+film1.getLength()+"\t"+film1.getRatings());				
			return film1;//AddFilm(languagesset, categoriesset, actorsset);
		}
		}
	if(flag==0)
	{
		System.out.println("Film not found");
	}
	break;
	}
	return null;
	}


//Delete  Film
public Film removeFilm(Collection<Film> lst,int choice)
{
	int flag = 0;
	switch(choice)
	{
	case 1:
			System.out.println("Enter the Rating");
			int rate=sc.nextInt();
			for(Film film:lst)
			{
				if(film.getRatings()==rate)
				{
					flag=1;
					//lst.remove(film);
					return film;
				}
			}
			if(flag==0)
			{
				System.out.println("Film not found");
			}
			break;
	case 2:
		System.out.println("Enter Film Name");
		String film=sc.next();
		for(Film film1:lst)
		{
		if(film1.getTitle().equals(film))
		{
			flag=1;
			//lst.remove(film);
			return film1;
		}
		}
	if(flag==0)
	{
		System.out.println("Film not found");
	}
	break;
	case 3:
		System.out.println("Enter Release Date");
		String date=sc.next();
		Date dt=new Date(date);
		for(Film film1:lst)
		{
		if(film1.getReleaseYear().equals(dt))
		{
			flag=1;
			//lst.remove(1);
			return film1;
		}
		}
	if(flag==0)
	{
		System.out.println("Film not found");
	}
	break;
	}
	return null;
	}

}