package com.flp.fms.dao;

import java.util.HashSet;
import java.util.Set;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao{

	@Override
	public Set<Actor> getActors() {
		
		Set<Actor> actors=new HashSet<>();
		actors.add(new Actor(1,"Aamir","Khan"));
		actors.add(new Actor(2,"Shahrukh","Khan"));
		actors.add(new Actor(3,"Hrithik","Roshan"));
		actors.add(new Actor(4,"Tom","Cruise"));
		actors.add(new Actor(5,"Priyanka","Chopra"));
		return actors;
	}

}
