function validateForm()

{
	var flag=true;
	
	
	//alert("hello");
	var title=addfilm.filmtitle.value;
	var letters = /^[A-Za-z]+$/; 

	var length=addfilm.length.value;
	
	var cost=addfilm.replacementcost.value;
	
	var rentalDate = addfilm.rentaldate.value;
	
	var releaseyear=addfilm.releasedate.value;
		
	if((title==""|| title==null)|| !title.match(letters))
	
	{
		
		document.getElementById("titleerr").innerHTML="* Please enter a title";
		
		flag=false;
	}
	
	else
	 {
		document.getElementById("titleerr").innerHTML=" ";
	 }
	
   if((length==""||length==null)|| !islengthvalid())
   
   {
		
		document.getElementById("lenghterr").innerHTML="*Please enter a value below 1000";
		
		flag = false;
	}
   
	else
	 {
		document.getElementById("lenghterr").innerHTML="";
	    
	 }
   
//   
//   if(cost==""||cost==null|| !isreplacementcostvalid())
//   {
//		
//		document.getElementById("replacementcosterr").innerHTML="*Please enter a valid cost";
//		
//		flag = false;
//	}
//		
//	else
//		
//		{
//		document.getElementById("replacementcosterr").innerHTML="";
//		
//		}
//   
//   if(rentalDate==""||rentalDate==null|| !isrentaldurationvalid())
//   {
//		
//		document.getElementById("rentaldurationerr").innerHTML="*Invalid rental duration";
//		
//		flag = false;
//	}
//		
//	else
//		{
//		document.getElementById("rentaldurationerr").innerHTML="";
//		}
//   
//   
//   if(releaseyear==""||releaseyear==null)
//   {
//		
//		document.getElementById("rentaldurationerr").innerHTML="*Invalid rental duration";
//		
//		flag = false;
//	}
//		
//	else
//		{
//		document.getElementById("rentaldurationerr").innerHTML="";
//		}
//   
//   
//   



   

     
   return flag;
 
}
////Title Validation
//
//function istitlevalidate()  
//{   
//		var filmtitle=addfilm.filmtitle.value;
//		
//		var letters = /^[A-Za-z]+$/;  
//		if(filmtitle.match(letters))  
//		{  
//			document.getElementById("titleerr").innerHTML="";
//			return true;  
//		}  
//		else  
//		{  
//			document.getElementById("titleerr").innerHTML="*Title should only contain alphabet"; 
//			filmtitle.focus();  
//			return false;  
//		}  
//}  
//
//
//
////Description Validation
//function isdescriptionvalidate()  
//{   
//		var filmdescription=addfilm.filmdescription.value;
//		
//		var letters = /^[A-Za-z]+$/;  
//		if(filmdescription.match(letters))  
//		{  
//			document.getElementById("diserr").innerHTML="";
//			return true;  
//		}  
//		else  
//		{  
//			document.getElementById("diserr").innerHTML="*Description should only contain alphabet"; 
//			filmdescription.focus();  
//			return false;  
//		}  
//}  
//
//
//
////Length Validation
function islengthvalid(){
	
	var filmlength=addfilm.length.value;

    //if(isNaN(filmlength)||filmlength>1 || filmlength<1000){
    	
    	 if(filmlength>=1 && filmlength<=1000){
    	
    	
    	document.getElementById("lenghterr").innerHTML="";
		return true;  
    }
    else
    {
    	document.getElementById("lenghterr").innerHTML="*Length should a number be between 1 to 1000"; 
    	filmlength.focus();  
		return false; 
    }
    }
    
//	
//}
//
//
//
////Length Validation
//function isreplacementcostvalid(){
//	
//	var replacementcost=addfilm.replacementcost.value;
//
//  //if(isNaN(filmlength)||filmlength>1 || filmlength<1000){
//  	
//  	 if(replacementcost>=1 && replacementcost<=1000){
//  	
//  	
//  	document.getElementById("replacementcosterr").innerHTML="";
//		return true;  
//  }
//  else
//  {
//  	document.getElementById("replacementcosterr").innerHTML="*Replacement Cost should a number be between 1 to 1000"; 
//  	replacementcost.focus();  
//		return false; 
//  }
//  
//	
//}
//
//
//
////ReleaseDate And RentalDuration (Rental>Release)
//
//function isrentaldurationvalid(){
//	
//	var ReleaseDate=addfilm.releasedate.value;
//	var RentalDuration=addfilm.rentalduration.value;
//
//
//    	
//    	 if(RentalDuration>ReleaseDate){
//    	
//    	
//    	document.getElementById("rentaldurationerr").innerHTML="";
//		return true;  
//    }
//    else
//    {
//    	document.getElementById("rentaldurationerr").innerHTML="*RentalDate shhould be Greater than ReleaseDate"; 
//    	rentalduration.focus();  
//		return false; 
//    }
//    
//	
//}
//
////Rating Validation
//function isratingSelected()  
//{  
//	var Rating=addfilm.rating.value;
//if(Rating.value != "Default")  
//{  
//	  
//	document.getElementById("ratingerr").innerHTML="";
//	return true; 
//}  
//else  
//{  
//	document.getElementById("ratingerr").innerHTML="*Please Select any one Rating"; 
//	rating.focus();  
//	return false; 
//	
//}  
//
//
//}  
//
//
//function displayFilmDetails(){
//	//alert("hello");
//	var filmid1=SearchFilm.filmid.value;	
//
//	var title1=SearchFilm.title.value;
//		
//		//Ajax Code 
//		var xhr = new XMLHttpRequest();
//	    xhr.onreadystatechange = function() {
//	        if (xhr.readyState == 4) {
//	            var data = xhr.responseText;
//	             document.getElementById('displayFilm').innerHTML=data;
//	        }
//	    }
//	    xhr.open('GET', 'DisplayFilmServlet?filmid='+filmid1 +'&title='+title1  , true);
//	  
//	    xhr.send(null);
//
//
//}

