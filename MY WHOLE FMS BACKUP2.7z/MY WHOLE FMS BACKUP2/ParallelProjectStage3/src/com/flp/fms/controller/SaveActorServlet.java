package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorService;
import com.flp.fms.service.ActorServiceImpl;

/**
 * Servlet implementation class SaveActorServlet
 */
public class SaveActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	PrintWriter out=response.getWriter();
		
		Actor actor=new Actor();
		
		ActorService actorService=new ActorServiceImpl();
		
		actor.setActor_FirstName(request.getParameter("actorname"));
		actor.setActor_LastName(request.getParameter("lastname"));
		
		actorService.addActor(actor);
		
		request.getRequestDispatcher("AddActorServlet").forward(request, response);
		
	}
		
		
		
		
		
	

}
