package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorService;
import com.flp.fms.service.ActorServiceImpl;

/**
 * Servlet implementation class SearchActor
 */
public class SearchActor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		ActorService actorService=new ActorServiceImpl();
		
		Actor actor=new Actor();
		
		if(request.getParameter("byId")!="")
			actor.setActor_Id(Integer.parseInt(request.getParameter("byId")));
		if(request.getParameter("byName")!="")
			actor.setActor_FirstName((request.getParameter("byName")));
		
		List<Actor> actors=actorService.searchActorDetails(actor);
		PrintWriter out=response.getWriter();
		if(actors.isEmpty())
		{	out.println("<html>");
			out.println("<h2> Results Not found!<h2>");
			out.println("</html>");
		}
		
		else{
			out.println("<html>");
			out.println("<head>"
					+"<link rel='stylesheet' type='text/css' href='css/Styles.css'>"
					+ "</head>"
					+ "<body>"
					+ "<div style='margin-left:500px;'>  </div>"
					+ "<table border=1>"
					+ "<tr>"
					+ "<th> Actor Id </th>"
					+ "<th> First Name </th>"
					+ "<th>	Last Name	</th>"
					+ "</tr>");
			
				
				for(Actor actor1:actors){
					out.println("<tr>");
					out.println("<td>"+actor1.getActor_Id()+"</td>");
					out.println("<td>"+actor1.getActor_FirstName()+"</td>");
					out.println("<td>"+actor1.getActor_LastName()+"</td>");
					
					out.println("</tr>");
				}
					out.println("</table></body>");
		
					out.println("</html>");
				}
	}
	}


