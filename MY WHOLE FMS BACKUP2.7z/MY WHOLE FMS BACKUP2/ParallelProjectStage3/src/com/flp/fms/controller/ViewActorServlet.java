package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.service.ActorService;
import com.flp.fms.service.ActorServiceImpl;

/**
 * Servlet implementation class ViewActorServlet
 */
public class ViewActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out=response.getWriter();
		ActorService iactorservice=new ActorServiceImpl();
		
		out.println("<html>"
				+"<head>"
				+"<title>List All Actors OR Add/Remove Actors </title>"
				+ "<script type='text/javascript' src='js/myscript.js'></script>"
				+ "<link href='css/mystyle.css' rel='stylesheet' type='text/css'>"
				
				+"</head>");
		out.println("<body style='color:white;'>"
				+ "<h2 align='center'>Actors</h2>"
						+ "<form name='addActorForm' method='post' '>"
						+ "<table cellpadding='10px' cellspacing='10px' style='color:white;'>"
						+"&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"
						+"<a href='AddActorServlet'><h5 style='color:pink;'>Add Actors</h5></a>"
										
												
										+"&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"

										+"<a href='DeleteActorServlet'><h5 style='color:pink;'>Delete Actors</h5></a>"
										
+"&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp"

										+"<a href='ListAllActors'><h5 style='color:pink;'>List All Actors</h5></a>"
										
												+ "</table></form></body></html>");

}
}
