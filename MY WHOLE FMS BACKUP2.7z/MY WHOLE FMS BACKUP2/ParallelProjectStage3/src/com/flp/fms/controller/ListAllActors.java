package com.flp.fms.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorService;
import com.flp.fms.service.ActorServiceImpl;

/**
 * Servlet implementation class ListAllActors
 */
public class ListAllActors extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ActorService iactorservice=new ActorServiceImpl();
		
		List<Actor> actors=iactorservice.getActorList();
		
					
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head><title>List All Actors</title>"
				+ "<script type='text/javascript' src='js/myscript.js'></script>"
				+"<link rel='stylesheet' type='text/css' href='css/mystyle.css'>"
				+ "<style>"
				
				+ "table {"
				+ "  border-collapse: collapse;"
				+ "  width: 100%;"
				
				+ "}"

				+ "th, tr {"
				+ " text-align: center;"
				+ " padding: 8px;"
				+ "  color: white;"
				+ "}"

				+ "tr:nth-child{background-color: #c0c0c0}"

				+ "th {"
				+ "  background-color: teal;"
				+ "  color: white;"
				+ "}"
				+ "</style>"
				+ "</head>"
				+ "<body style='font-size:25px;' style=' color: white;'>"
				+ "<h2 align='center'>List Of Actors</h2>"
				+ "<center>"
				+ "<table border=1 width=700px align=center>"
				+ "<tr>"
				+ "<th>Actor Id</th>"
				+ "<th>First Name</th>"
				+ "<th>Last Name</th>"
				+ "</tr>");
		
			for(Actor actor:actors){
				out.println("<tr>");
				out.println("<td>"+actor.getActor_Id()+"</td>");
				out.println("<td>"+actor.getActor_FirstName()+"</td>");
				out.println("<td>"+actor.getActor_LastName()+"</td>");
				out.println("</tr>");
			}
				out.println("</table></center></body>");
	
				out.println("</html>");
}

	}
	


