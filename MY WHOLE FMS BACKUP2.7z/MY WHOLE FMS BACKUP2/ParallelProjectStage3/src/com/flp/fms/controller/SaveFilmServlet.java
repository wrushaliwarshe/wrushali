package com.flp.fms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmService;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class SaveFilmServlet
 */
public class SaveFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FilmService filmService=new FilmServiceImpl();
		Film film=new Film();
		
		Category cat=new Category();
		Actor actor=new Actor();
		
		Language lang=new Language(); 
		film.setTitle(request.getParameter("filmtitle"));
		film.setDescription(request.getParameter("filmdescription"));
		
		film.setLength(Integer.parseInt(request.getParameter("length")));
		//System.out.println(film.getLength());
		
		lang.setLanguage_Id(Integer.parseInt(request.getParameter("orgLang")));
		film.setOriginalLanguage(lang);
		
		ArrayList<Language> languages=new ArrayList<>();
		String[] str=request.getParameterValues("Languages");
		System.out.println(str);
		for(String str1:str){
			Language lang1=new Language(); 
			lang1.setLanguage_Id(Integer.parseInt(str1));
			languages.add(lang1);
		}
		film.setLanguages(languages);
		
		film.setRatings(Integer.parseInt(request.getParameter("rating")));
		film.setReleaseYear(new Date(request.getParameter("releasedate")));
		film.setRentalDuration(new Date(request.getParameter("rentalduration")));
		film.setReplacementCost(Integer.parseInt(request.getParameter("replacementcost")));
		
		cat.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(cat);
		//film.setLanguages(request.getParameter(""));
		film.setSpecialFeatures(request.getParameter("specialfeature"));
		
		Set<Actor> actors=new HashSet<>();
		String[] string=request.getParameterValues("actor");
		for(String str1:str){
			Actor actor1=new Actor(); 
			actor1.setActor_Id(Integer.parseInt(str1));
			actors.add(actor1);
		}
		film.setActors(actors);
		
		filmService.saveFilm(film);
		
//		if(filmService.saveFilm(film)==true){
//			
//			
//			request.getRequestDispatcher("AddFilmServlet").forward(request, response);
//			}
		}
		
		
	}

	


