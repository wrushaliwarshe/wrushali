package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Actor;

public interface ActorService {
	public int addActor(Actor actor);

	List<Actor> getActorList();
	
	public boolean deleteActorDetails(int actorid);
	
	public List<Actor> searchActorDetails(Actor actor);
	public Actor getSearchActorByID(int actorid);
	
	public int updateActorDetails(int actorid,Actor actor);
}
