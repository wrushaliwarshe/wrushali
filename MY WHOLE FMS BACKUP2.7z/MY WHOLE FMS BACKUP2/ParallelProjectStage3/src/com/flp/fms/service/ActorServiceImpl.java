package com.flp.fms.service;

import java.util.List;

import com.flp.fms.dao.ActorDao;
import com.flp.fms.dao.ActorDaoImpl;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements ActorService{
	ActorDao actorDao=new ActorDaoImpl();
	@Override
	public int addActor(Actor actor) {
		// TODO Auto-generated method stub
	 return actorDao.addActor(actor);
	}

	@Override
	public List<Actor> getActorList() {
		// TODO Auto-generated method stub
		return actorDao.getActorList();
	}

	@Override
	public boolean deleteActorDetails(int actorid) {
		// TODO Auto-generated method stub
		return actorDao.deleteActorDetails(actorid);
	}

	@Override
	public List<Actor> searchActorDetails(Actor actor) {
		// TODO Auto-generated method stub
		return actorDao.searchActorDetails(actor);
	}

	@Override
	public int updateActorDetails(int actorid, Actor actor) {
		// TODO Auto-generated method stub
		return actorDao.updateActorDetails(actorid, actor);
	}

	@Override
	public Actor getSearchActorByID(int actorid) {
		// TODO Auto-generated method stub
		return actorDao.getSearchActorByID(actorid);
	}

}
