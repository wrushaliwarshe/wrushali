package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface FilmService {
	
	//-----------Getting All Languages--------//
	public ArrayList<Language> getLanguages();
	
	//-----------Getting All Actors----------//
	public ArrayList<Actor> getActors();
	
	//-----------Getting All Categories------//
	public ArrayList<Category> getCategories();

	//----------Calling Save Film method of DAO---------//
	public Boolean saveFilm(Film film);

	//----------Getting All Films-----------//
	public ArrayList<Film> getAllFilms();
	
	//----------Deleting Film--------------//
	public boolean deleteFilm(int filmid);
	
	//----------Searching Film by All Fields-------//
	public List<Film> searchFilm(Film film);
	
	//----------Updating Film---------------//
	public int updateFilm(int id,Film film);
	
	//----------Searching Film by id--------//
	public Film getSearchFilmByID(int id);
	
}
