package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;



public class FilmDaoImpl implements FilmDao{
	int id;
	
//-----------------------------------------------------------//	
//-------------Connection Method--------------//
	public Connection getConnection(){
		
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fms","root","Pass1234");
			System.out.println("esta");
			
		    } catch (ClassNotFoundException e) {
			     e.printStackTrace();
		    } catch (SQLException e) {
			     e.printStackTrace();
		    }
		return connection;
	        }	
	
	
	
//-----------------------------------------------------------//	
//-------------Getting Languages List From DataBase--------------//	
@Override
public ArrayList<Language> getLanguages() {
	ArrayList<Language> languages=new ArrayList<>();

	Connection con=getConnection();
	String sql="Select * from LANGUAGE";
		try{
		PreparedStatement pst=(PreparedStatement)con.prepareStatement(sql);
		
		ResultSet rs=pst.executeQuery();
		
		while(rs.next()){
			Language lang=new Language();
			lang.setLanguage_Id(rs.getInt(1));
			lang.setLanguage_Name(rs.getString(2));
			languages.add(lang);
		}
		
		}catch (SQLException e) {
			
			e.printStackTrace();
				
	    }
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return languages;
	}
	


//-----------------------------------------------------------//	
//-------------Getting Actor List From DataBase--------------//
@Override
public ArrayList<Actor> getActors() {
	ArrayList<Actor> actors=new ArrayList<>();

	Connection con=getConnection();
	String sql="Select * from actors";
	try{
	PreparedStatement pst=(PreparedStatement)con.prepareStatement(sql);
	
	ResultSet rs=pst.executeQuery();
	
	while(rs.next()){
		Actor actor=new Actor();
		actor.setActor_Id(rs.getInt(1));
		actor.setActor_FirstName(rs.getString(2));
		actor.setActor_LastName(rs.getString(3));
		actors.add(actor);
	}
	
	}catch (SQLException e) {
		
		e.printStackTrace();		
  }
	try {
		con.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return actors;
}	


//-----------------------------------------------------------//	
//-------------Getting Category List From DataBase--------------//
@Override
public ArrayList<Category> getCategories(){
	ArrayList<Category> categories=new ArrayList<>();

	Connection con=getConnection();
	String sql="Select * from category";
	try{
	PreparedStatement pst=(PreparedStatement)con.prepareStatement(sql);
	
	ResultSet rs=pst.executeQuery();
	
	while(rs.next()){
		Category cat=new Category();
		cat.setCategory_Id(rs.getInt(1));
		cat.setCategory_Name(rs.getString(2));
		
		categories.add(cat);
	}
	
	}catch (SQLException e) {
		
		e.printStackTrace();
		
	}
	try {
		con.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return categories;
	
	
}



//-----------------------------------------------------------//	
//-------------Save Film In DataBase--------------//
	
public Boolean saveFilm(Film film){
	Connection con=getConnection();
	Boolean flag=false;
	String sql="insert into film (title,description,releaseYear,originalLanguage,"
		+ "rentalDuration,length,replacementCost,ratings,specialFeatures,category)"
		+"values(?,?,?,?,?,?,?,?,?,?)";
	Category cat=new Category();
				
				
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1,film.getTitle());
			pst.setString(2,film.getDescription());
			pst.setDate(3,new java.sql.Date(film.getReleaseYear().getTime()));
			pst.setInt(4,(film.getOriginalLanguage()).getLanguage_Id());
			pst.setDate(5, new java.sql.Date(film.getRentalDuration().getTime()));
			pst.setInt(6, film.getLength());
			pst.setDouble(7, film.getReplacementCost());
			pst.setInt(8,film.getRatings());
			pst.setString(9,film.getSpecialFeatures());
			pst.setInt(10, (film.getCategory()).getCategory_Id());
					
//------Extract the id of the Title inserted-------//
			pst.executeUpdate();
			Connection con1=getConnection();
					
					
			String sql1="Select filmid from film order by filmid desc limit 1";
			PreparedStatement pst1=con1.prepareStatement(sql1);
//			System.out.println("title="+film.getTitle());	
//			pst1.setString(1,film.getTitle());
			ResultSet rs=pst1.executeQuery();
					
				if(rs.next())
					id = rs.getInt(1);
					System.out.println("ID="+id);	
					
				} catch (SQLException e) {
					e.printStackTrace();	
				}
				
					
					
//--------Add multiple languages into the third party table---//
						
	Iterator<Language> itr = film.getLanguages().iterator();		
		
		try {
			 int count = 0;
			 for(Language lan: film.getLanguages()){
			 String sql1="INSERT INTO film_language (film_id,language_Id)"
								+ "	 values(?,?)";
			 PreparedStatement pst1=con.prepareStatement(sql1);
			 pst1.setInt(1, id);
			 pst1.setInt(2, lan.getLanguage_Id());
					    
			 int count1=pst1.executeUpdate();    
			                                       }	   
			} catch (Exception e) {}
				
				
//-------Adding actors in film_actor table---------//
Iterator<Actor> itr2 = film.getActors().iterator();

	try {
		int count = 0;
		for(Actor act: film.getActors()){
		String sql1="INSERT INTO film_actors (film_id,actor_id)"
								+ "	 values(?,?)";
						
		PreparedStatement pst2=con.prepareStatement(sql1);
	    pst2.setInt(1, id);
		pst2.setInt(2, act.getActor_Id());
					    
		int count1=pst2.executeUpdate();
					    
		flag=true;
				               			}
					   
		} catch (Exception e) {}
		
	try {
		con.close();
		} catch (SQLException e) {
		   e.printStackTrace();
				                 }
				return flag;
			}



//-----------------------------------------------------------//	
//-------------Getting List of Film DataBase--------------//
@Override
public ArrayList<Film> getAllFilms() {
	ArrayList<Film> films=new ArrayList<>();
	String sql="Select * from film";
	Connection con=getConnection();
	try{
		PreparedStatement pst=con.prepareStatement(sql);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			Film film=new Film();
			film.setFilm_Id(rs.getInt(1));
			film.setTitle(rs.getString(2));
		    film.setDescription(rs.getString(3));
		    film.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
		 
		 
		 String subsql;
   subsql="select language_name from language where language_id="+rs.getInt(5);
			PreparedStatement pst1=con.prepareStatement(subsql);
			ResultSet rs3=pst1.executeQuery();
			Language lang=new Language();
			if(rs3.next())
			{
				lang.setLanguage_Id(rs.getInt(5));
				lang.setLanguage_Name(rs3.getString(1));
			}
			
			film.setOriginalLanguage(lang);
			film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
			film.setLength(rs.getInt(7));
		    film.setReplacementCost(rs.getInt(8));
		    film.setRatings(rs.getInt(9));
		    film.setSpecialFeatures(rs.getString(10));
    subsql="select category_name from category where category_id="+rs.getInt(11);
			PreparedStatement pst3=con.prepareStatement(subsql);
		    rs3=pst3.executeQuery();
			if(rs3.next())
			{
				Category cat=new Category();
				cat.setCategory_Id(rs.getInt(11));
				cat.setCategory_Name(rs3.getString(1));
				film.setCategory(cat);
			}
			
	subsql="select language_id from film_language where film_id="+rs.getInt(1);
			System.out.println(rs.getInt(1));
			pst3=con.prepareStatement(subsql);
		    rs3=pst3.executeQuery();
		    List<Language> languages=new ArrayList<>();
			while(rs3.next())
			{
										
String subsql1="select language_name from language where language_id="+rs3.getInt(1);
				PreparedStatement pst2=con.prepareStatement(subsql1);
				ResultSet rs1=pst2.executeQuery();
				while(rs1.next()){
					Language langs=new Language();
					langs.setLanguage_Id(rs3.getInt(1));
					langs.setLanguage_Name(rs1.getString(1));
					languages.add(langs);
					
				}
			}
			film.setLanguages(languages);
	subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
		
			pst3=con.prepareStatement(subsql);
		    rs3=pst3.executeQuery();
		    Set<Actor> actors=new HashSet<>();
			while(rs3.next())
			{
String subsql1="select firstname,lastname from actors where actor_id="+rs3.getInt(1);
				PreparedStatement pst2=con.prepareStatement(subsql1);
				ResultSet rs1=pst2.executeQuery();
				while(rs1.next()){
					Actor actr=new Actor();
					actr.setActor_FirstName(rs1.getString(1));
					actr.setActor_LastName(rs1.getString(2));
					actr.setActor_Id(rs3.getInt(1));
					actors.add(actr);
					
		    }
			}
			film.setActors(actors);
			film.setLanguages(languages);
			System.out.println(film);
			films.add(film);
		}
		}catch (SQLException e) {
		   e.printStackTrace();
		}
	   try {
		con.close();
	   } catch (SQLException e) {
		
		e.printStackTrace();
	   }
	return films;
}



//-----------------------------------------------------------//	
//-------------Search Film From DataBase--------------//
@Override
public List<Film> searchFilm(Film film) {
	//List<Film> films=new ArrayList<>();
	
	Connection con=getConnection();
	int count=0;
	String sql="select * from film where";
	ArrayList<Film> films=new ArrayList<Film>();
	System.out.println(film);
	if(film!=null)
	{
		if(film.getFilm_Id()>0)
		{
			
			sql+=" filmid="+film.getFilm_Id();
			
			count=1;
		}
		
		if(film.getTitle()!=null)
		{
			if(count==1)
			{
				sql+=" and title='"+film.getTitle()+"'";
			}
			else
			{
				sql+=" title='"+film.getTitle()+"'";
			}
			count=2;
		}
	

		if(film.getRatings()>0)
		{
			if(count==1||count==2)
			{
				sql+=" and ratings="+film.getRatings();
			}
			else
			{
				sql+=" ratings="+film.getRatings();
			}
			count=3;
		}
		if(film.getActors()!=null)
		{
			Actor actor=new Actor();
			Set<Actor> act=film.getActors();
			for(Actor a:act)
				actor=a;
			if(count==1||count==2||count==3)
			{
				sql+=" and filmid In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
				
			}else
			{
			sql+=" filmid In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
			}
			count=4;
		}
		if(film.getLanguages()!=null)
		{
			Language lang=new Language();
			List<Language> langs=film.getLanguages();
		
			for(Language l:langs)
				lang=l;
			if(count==1||count==2||count==3||count==4)
			{
				sql+=" and( filmid In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or filmid In( Select filmid from film where originalLanguage="+lang.getLanguage_Id()+"))";
				
			}else
			{
			sql+=" ( filmid In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or filmid In (Select filmid from film where originalLanguage="+lang.getLanguage_Id()+"))";
			
			}
			count=5;
		}
	
		 
		if(film.getReleaseYear()!=null)
		{
			if(count==1||count==2||count==3||count==4||count==5)
			{
				sql+=" and releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
			}
			else
			{
				sql+=" releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
			}
			count=6;
		}
		System.out.println(sql);
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
		
			while(rs.next())
			{
				Film film1=new Film();
				film1.setFilm_Id(rs.getInt(1));
				film1.setTitle(rs.getString(2));
				film1.setDescription(rs.getString(3));
				
				film1.setReleaseYear(rs.getDate(4));
				
				String subsql;
	subsql="select language_name from LANGUAGE where language_id="+rs.getInt(5);
				PreparedStatement pst1=con.prepareStatement(subsql);
				ResultSet rs3=pst1.executeQuery();
				Language lang=new Language();
				if(rs3.next())
				{
					lang.setLanguage_Id(rs.getInt(5));
					lang.setLanguage_Name(rs3.getString(1));
				}
				film1.setOriginalLanguage(lang);
				film1.setRentalDuration(rs.getDate(6));
				film1.setLength(rs.getInt(7));
				film1.setReplacementCost(rs.getInt(8));
				film1.setRatings(rs.getInt(9));
				film1.setSpecialFeatures(rs.getString(10));
				
	subsql="select category_name from category where category_id="+rs.getInt(11);
				PreparedStatement pst3=con.prepareStatement(subsql);
			    rs3=pst3.executeQuery();
				if(rs3.next())
				{
					Category cat=new Category();
					cat.setCategory_Id(rs.getInt(11));
					cat.setCategory_Name(rs3.getString(1));
					film1.setCategory(cat);
				}
				
	subsql="select language_id from film_language where film_id="+rs.getInt(1);
				System.out.println(rs.getInt(1));
				pst3=con.prepareStatement(subsql);
			    rs3=pst3.executeQuery();
			    List<Language> languages=new ArrayList<>();
				while(rs3.next())
				{
											
String subsql1="select language_name from language where language_id="+rs3.getInt(1);
					PreparedStatement pst2=con.prepareStatement(subsql1);
					ResultSet rs1=pst2.executeQuery();
					while(rs1.next()){
						Language langs=new Language();
						langs.setLanguage_Id(rs3.getInt(1));
						langs.setLanguage_Name(rs1.getString(1));
						languages.add(langs);
						
					}
				}
				film1.setLanguages(languages);
	subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
			
				pst3=con.prepareStatement(subsql);
			    rs3=pst3.executeQuery();
			    Set<Actor> actors=new HashSet<>();
				while(rs3.next())
				{
	String subsql1="select firstName,lastName from actors"
							+ " where actor_id="+rs3.getInt(1);
					PreparedStatement pst2=con.prepareStatement(subsql1);
					ResultSet rs1=pst2.executeQuery();
					while(rs1.next()){
						Actor actr=new Actor();
						actr.setActor_FirstName(rs1.getString(1));
						actr.setActor_LastName(rs1.getString(2));
						actr.setActor_Id(rs3.getInt(1));
						actors.add(actr);
						
					}
				}
				film1.setActors(actors);
				film1.setLanguages(languages);
				System.out.println(film1);
				films.add(film1);
				} 
			}catch (SQLException e) {
			  e.printStackTrace();
		    }
			}
	try {
		con.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return films;
}
	


//@Override
//public Film searchFilm(int filmId) {
//	
//	Film film = new Film();
//		
//	
//	Connection con =getConnection();
//		
//	String sql = "select * from film where filmId="+filmId;
//		
//	try {
//
//			PreparedStatement pst = con.prepareStatement(sql);
//			ResultSet rs = pst.executeQuery();
//
//			//calling the createFilm() function 
//			for(Film fil : createFilmList(con, rs)){
//				
//				film = fil;
//			}
//			con.close();
//
//	} catch (SQLException e) {
//		e.printStackTrace();
//	}
//		
//	return film;
//}





	
//	public Set<Actor> getAllActorsOfFilm(int filmId){
//		
//		Set<Actor> actors = new HashSet<>();
//			
//		String sql3="select actorId from film_actors where filmId="+filmId;
//		PreparedStatement stmt3;
//		try {
//				Connection con=getConnection();
//			stmt3 = con.prepareStatement(sql3);			
//			ResultSet rs3 = stmt3.executeQuery();
//				
//			while(rs3.next()){
//					
//				//retrieving actor details from actor table
//				String sql4 = "select * from actor where actorId="+rs3.getInt(1);
//				PreparedStatement stmt4 = con.prepareStatement(sql4);
//				ResultSet rs4 = stmt4.executeQuery();
//					
//				while(rs4.next()){
//						
//					Actor act = new Actor();
//					act.setActor_Id(rs4.getInt(1));
//					act.setActor_FirstName(rs4.getString(2));
//					act.setActor_LastName(rs4.getString(3));
//												
//					actors.add(act);					
//				}
//			}			
//				
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}			
//			
//		return actors;
//	}
	
	
		
	
//-----------------------------------------------------------//	
//-------------Deleting Film From DataBase--------------//	
@Override
public boolean deleteFilm(int filmid){
	Connection con=getConnection();
	boolean flag=false;
	String sql="DELETE film ,film_actors,film_language FROM film LEFT JOIN film_actors ON film .filmid = film_actors.film_id LEFT JOIN film_language ON film_language.film_id = film.filmid WHERE film .filmid=?";
	try{
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, filmid);
		int count =pst.executeUpdate();

		if(count>0)
			flag=true;
		
				}catch (SQLException e) {
					
					e.printStackTrace();
				}
	
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return flag;
}



//-----------------------------------------------------------//	
//-------------Updating Film--------------//
@Override
public int updateFilm(int id,Film film){
	Connection con=getConnection();
	int  count=0;
	String sql="update film set title=?,description=?,releaseYear=?,originalLanguage=?,rentalDuration=?,LENGTH=?,replacementCost=?,ratings=?,specialFeatures=?,category=? where filmid=?";
	String sql1="delete from film_language where film_id=?";
	String sql4="delete from film_actors where film_id=?";

try {
	PreparedStatement pst=con.prepareStatement(sql);
	//pst.setString(1, film.getTitle());
	pst.setString(1, film.getTitle());
	pst.setString(2, film.getDescription());
	pst.setDate(3, new Date(film.getReleaseYear().getTime()));
	int language=film.getOriginalLanguage().getLanguage_Id();
	pst.setInt(4, language);
	pst.setDate(5, new Date(film.getRentalDuration().getTime()));
	pst.setInt(6, film.getLength());
	pst.setDouble(7,film.getReplacementCost());
	
	pst.setInt(8,film.getRatings());
	pst.setString(9,film.getSpecialFeatures());
	int category=film.getCategory().getCategory_Id();
	pst.setInt(10,category);
	pst.setInt(11, id);
	
	count=pst.executeUpdate();
	
	
//----delete from film_language-----//
	PreparedStatement pst1=con.prepareStatement(sql1);
	pst1.setInt(1, id);
    count=pst1.executeUpdate();
    
//-----delete from film_actors----//
	PreparedStatement pst4=con.prepareStatement(sql4);
	pst4.setInt(1, id);
    count=pst4.executeUpdate();
      
//-----insert into film_languages----//
String sql2="insert into film_language values(?,?)";
	PreparedStatement pst2=con.prepareStatement(sql2);
     List<Language> lang=film.getLanguages();
     System.out.println(lang);
	for(Language lang1:lang){
	pst2.setInt(1, id);
	pst2.setInt(2,lang1.getLanguage_Id());
    count=pst2.executeUpdate();
	}
    
String sql3="insert into film_actors values(?,?)";
	PreparedStatement pst3=con.prepareStatement(sql3);
    Set<Actor> actor=film.getActors();
	for(Actor act1:actor){
	pst3.setInt(1, id);
	pst3.setInt(2,act1.getActor_Id());
	 count=pst3.executeUpdate();
	}
	
	} catch (SQLException e) {
	  e.printStackTrace();
	}


	try {
	con.close();
	} catch (SQLException e) {
	e.printStackTrace();
	}

return count;
	
}



//-----------------------------------------------------------//	
//-------------Searching Film by Id--------------//
public Film getSearchFilmByID(int id) {
	Connection con=getConnection();
	Film film=new Film();
	String sql="select * from film where filmid=?";
	
	try {
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, id);
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
		/*	Film film=new Film();*/
			film.setFilm_Id(rs.getInt(1));
			film.setTitle(rs.getString(2));
			film.setDescription(rs.getString(3));
			film.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));


			String subsql;
	subsql="select language_name from language where language_id="+rs.getInt(5);
			PreparedStatement pst1=con.prepareStatement(subsql);
			ResultSet rs3=pst1.executeQuery();
			Language lang=new Language();
			if(rs3.next())
			{
				lang.setLanguage_Id(rs.getInt(5));
				lang.setLanguage_Name(rs3.getString(1));
			}

			film.setOriginalLanguage(lang);
			film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
			film.setLength(rs.getInt(7));
			film.setReplacementCost(rs.getInt(8));
			film.setRatings(rs.getInt(9));
			film.setSpecialFeatures(rs.getString(10));
    subsql="select category_name from category where category_id="+rs.getInt(11);
			PreparedStatement pst3=con.prepareStatement(subsql);
			rs3=pst3.executeQuery();
			if(rs3.next())
			{
				Category cat=new Category();
				cat.setCategory_Id(rs.getInt(11));
				cat.setCategory_Name(rs3.getString(1));
				film.setCategory(cat);
			}

	subsql="select language_id from film_language where film_id="+rs.getInt(1);
			System.out.println(rs.getInt(1));
			pst3=con.prepareStatement(subsql);
			rs3=pst3.executeQuery();
			List<Language> languages=new ArrayList<>();
			while(rs3.next())
			{
										
String subsql1="select language_name from language where language_id="+rs3.getInt(1);
				PreparedStatement pst2=con.prepareStatement(subsql1);
				ResultSet rs1=pst2.executeQuery();
				while(rs1.next()){
					Language langs=new Language();
					langs.setLanguage_Id(rs3.getInt(1));
					langs.setLanguage_Name(rs1.getString(1));
					languages.add(langs);
					
				}
			}
			film.setLanguages(languages);
	subsql="select actor_id from film_actors where film_id="+rs.getInt(1);

			pst3=con.prepareStatement(subsql);
			rs3=pst3.executeQuery();
			Set<Actor> actors=new HashSet<>();
			while(rs3.next())
			{
String subsql1="select firstname,lastname from actors where actor_id="+rs3.getInt(1);
				PreparedStatement pst2=con.prepareStatement(subsql1);
				ResultSet rs1=pst2.executeQuery();
				while(rs1.next()){
					Actor actr=new Actor();
					actr.setActor_FirstName(rs1.getString(1));
					actr.setActor_LastName(rs1.getString(2));
					actr.setActor_Id(rs3.getInt(1));
					actors.add(actr);
					}
					}
			        film.setActors(actors);
			        film.setLanguages(languages);	
					}		
		} catch (SQLException e) {
		   e.printStackTrace();
		}
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return film;
	}

}





