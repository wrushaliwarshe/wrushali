package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.*;

public interface FilmDao {
	
   //----Getting All Languages---//	
public ArrayList<Language> getLanguages();

   //----Getting  All Actors---//	
public ArrayList<Actor> getActors();

   //----Getting All Categories---//	
public ArrayList<Category> getCategories();

	//----Save film---//
public Boolean saveFilm(Film film);

	//----Getting All films---//	
public ArrayList<Film> getAllFilms();

	//----Searching film---//	
public List<Film> searchFilm( Film film);

	//----Deleting film---//	
public boolean deleteFilm(int filmid);

	//----Updating film---//	
public int updateFilm(int id,Film film);

	//----Searching film by id---//	
public Film getSearchFilmByID(int id);


	

}
