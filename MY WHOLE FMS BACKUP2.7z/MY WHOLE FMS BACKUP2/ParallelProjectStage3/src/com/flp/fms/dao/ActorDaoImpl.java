package com.flp.fms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class ActorDaoImpl implements ActorDao{
public Connection getConnection(){
		
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fms","root","Pass1234");
			System.out.println("esta");
			
		    } catch (ClassNotFoundException e) {
			     e.printStackTrace();
		    } catch (SQLException e) {
			     e.printStackTrace();
		    }
		return connection;
	        }	
	
	
	FilmDao filmDao=new FilmDaoImpl();
	@Override
	public List<Actor> getActorList() {
		List<Actor> actor=new ArrayList<>();
		
		
		Connection con=getConnection();
		
		String sql="select * from actors";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActor_Id(rs.getInt(1));
				actor1.setActor_FirstName(rs.getString(2));
				actor1.setActor_LastName(rs.getString(3));
				actor.add(actor1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}

	@Override
	public int addActor(Actor actor) {
		// TODO Auto-generated method stub
				//return getActorList();
		Connection con=getConnection();
		String sql="insert into actors(firstName,lastName)values(?,?)";
		int count=0;
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			
			pst.setString(1, actor.getActor_FirstName());
			pst.setString(2,actor.getActor_LastName());
			
		 count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
//Remove actor from the database
	@Override
	public boolean deleteActorDetails(int actorid) {
		boolean flag=false;
		String sql="delete from actors where actor_id=?";
		Connection con=getConnection();
		
		   	 try {
					PreparedStatement pst=con.prepareStatement(sql);
				
				pst.setInt(1,actorid);
				 
				 
				 int count=pst.executeUpdate();
				 

					if(count>0)
						flag=true;
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		   	 
		   	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return flag;
	}

	//search actor from the database
	@Override
	public List<Actor> searchActorDetails(Actor actor) {
		
		Connection con=getConnection();
		
		int count=0;
		String sql="select * from actors where";
		List<Actor> actors=new ArrayList<Actor>();
		
		if(actor!=null)
		{
			if(actor.getActor_Id()>0)
			{
				
				sql+=" actor_id="+actor.getActor_Id();
				
				count=1;
			}
			
			if(actor.getActor_FirstName()!=null)
			{
				if(count==1)
				{
					sql+=" and firstName='"+actor.getActor_FirstName()+"'";
				}
				else
				{
					sql+=" firstName='"+actor.getActor_FirstName()+"'";
				}
				count=2;
			}
		}
		
	
			
			try {
				PreparedStatement pst= con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
					Actor actor1=new Actor();
					actor1.setActor_Id(rs.getInt(1));
					actor1.setActor_FirstName(rs.getString(2));
					actor1.setActor_FirstName(rs.getString(3));
					
					actors.add(actor1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return actors;
	}

	//update actor
	@Override
	public int updateActorDetails(int actorid, Actor actor) {
		
         Connection con=getConnection();
		System.out.println("DAO="+actorid);
		int count=0;
		
		String sql="update actors set firstName=?,lastName=? where actor_id="+actorid;
		
		
			
			try {
				PreparedStatement pst = con.prepareStatement(sql);
				
				pst.setString(1,actor.getActor_FirstName());
				pst.setString(2, actor.getActor_LastName());
				
				count=pst.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return count;
	}

	@Override
	public Actor getSearchActorByID(int actorid)  {

		Connection con=getConnection();
		
		Actor actor=new Actor();
		
		String sql="select * from actors where actor_id=?";
		
		
		try {
			PreparedStatement pst= con.prepareStatement(sql);
			pst.setInt(1, actorid);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
			
					actor.setActor_Id(rs.getInt(1));
					actor.setActor_FirstName(rs.getString(2));
					actor.setActor_FirstName(rs.getString(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}

	
	
	
	
}
