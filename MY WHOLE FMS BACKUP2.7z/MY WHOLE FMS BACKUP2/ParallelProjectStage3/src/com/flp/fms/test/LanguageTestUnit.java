package com.flp.fms.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmService;
import com.flp.fms.service.FilmServiceImpl;

public class LanguageTestUnit {

	@Test
	public void test() {
		
	}

FilmService  serviceFilm=new FilmServiceImpl();
	
	@Test
	public void WhenListOfLanguagesIsNotNull(){
		List<Language> langs=new ArrayList<>();
		langs.add(new Language(1,"English"));
		langs.add(new Language(2,"Hindi"));
		langs.add(new Language(3,"Marathi"));
		langs.add(new Language(4,"Tamil"));
		langs.add(new Language(5,"Malyalam"));
		langs.add(new Language(6,"Bengali"));
		langs.add(new Language(7,"Korean"));
		assertEquals(serviceFilm.getLanguages(),langs);
	}
	
	@Test
	public void WhenListOfLanguagesIsNull(){
		assertEquals(null,null);
	}
	
}
