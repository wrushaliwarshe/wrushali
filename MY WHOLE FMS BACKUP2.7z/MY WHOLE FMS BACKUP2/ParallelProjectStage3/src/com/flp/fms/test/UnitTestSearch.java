package com.flp.fms.test;

import static org.junit.Assert.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.*;
public class UnitTestSearch {

	@Test
	public void test() {
	}
	
	FilmService  serviceFilm=new FilmServiceImpl();
	

	
	@Test
	public void WhenAddFilmObjectIsNotNull() throws ParseException{
		Film film=new Film();
		film.setFilm_Id(1);
		film.setCategory(new Category(1,"Romance"));
		film.setLength(456);
		Set<Actor> actors=new HashSet<>();
		actors.add(new Actor(1,"Will","Smith"));
		actors.add(new Actor(2,"Hugh","Jackman"));
		film.setActors(actors);
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1,"English"));
		languages.add(new Language(2,"Hindi"));
		film.setLanguages(languages);
		Language orglang=new Language();
		orglang.setLanguage_Id(1);
		orglang.setLanguage_Name("English");
		film.setOriginalLanguage(orglang);
		film.setTitle("Inception");
		film.setDescription("Intriguing");
		String strDate1 = "2016-04-06";
		DateFormat formatter1 = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date = formatter1.parse(strDate1);
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		film.setReleaseYear(sqlDate);
		String strDate2 = "2016-04-13";
		DateFormat formatter2 = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date2 = formatter2.parse(strDate2);
		java.sql.Date sqlDate2 = new java.sql.Date(date.getTime());
		film.setRentalDuration(sqlDate2);
	assertEquals(serviceFilm.saveFilm(film), true);
	}
	
	
	
	@Test
	public void filmObjectIsNullWhenSearchById()
	{
		 Film film=null;
        assertNotEquals(film, serviceFilm.getSearchFilmByID(1));
	}
	
	
	@Test
	public void isFilmNotPresent()
	{
		 List<Film> films=serviceFilm.getAllFilms();
		 Film film1=new Film();
		 for(Film film:films)
			 film1=film;
        assertNotEquals(film1, serviceFilm.searchFilm(film1));
	}
	
	@Test
	public void isFilmNotPresentToDelete()
	{
		
		 assertFalse(serviceFilm.deleteFilm(40));
		
	}
	

	@Test
		public void WhenDeleteFilm() throws ParseException{
			Film film=new Film();
			film.setFilm_Id(1);
			film.setCategory(new Category(1,"Romance"));
			film.setLength(456);
			Set<Actor> actors=new HashSet<>();
			actors.add(new Actor(1,"Will","Smith"));
			actors.add(new Actor(2,"Hugh","Jackman"));
			film.setActors(actors);
			List<Language> languages=new ArrayList<>();
			languages.add(new Language(1,"English"));
			languages.add(new Language(2,"Hindi"));
			film.setLanguages(languages);
			Language orglang=new Language();
			orglang.setLanguage_Id(1);
			orglang.setLanguage_Name("English");
			film.setOriginalLanguage(orglang);
			film.setTitle("Inception");
			film.setDescription("Intriguing");
			String strDate1 = "2016-04-06";
			DateFormat formatter1 = new SimpleDateFormat("yyyy-mm-dd");

			java.util.Date date = formatter1.parse(strDate1);
			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
			film.setReleaseYear(sqlDate);
			String strDate2 = "2016-04-13";
			DateFormat formatter2 = new SimpleDateFormat("yyyy-mm-dd");

			java.util.Date date2 = formatter2.parse(strDate2);
			java.sql.Date sqlDate2 = new java.sql.Date(date.getTime());
			film.setRentalDuration(sqlDate2);
		assertEquals(serviceFilm.deleteFilm(film.getFilm_Id()), true);
			
		}


		
	    


}
