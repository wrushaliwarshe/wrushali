package com.flp.fms.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.FilmService;
import com.flp.fms.service.FilmServiceImpl;

public class ActorsTestUnit {

	@Test
	public void test() {
	}
		FilmService  serviceFilm=new FilmServiceImpl();
		
		
		
		@Test
		public void WhenListOfActorsIsNotNull(){
			List<Actor> actors=new ArrayList<>();
			actors.add(new Actor(1,"Will","Smith"));
			actors.add(new Actor(2,"Hugh","Jackman"));
			actors.add(new Actor(3,"Tom","Hnaks"));
			actors.add(new Actor(4,"Nana","Patekar"));
			actors.add(new Actor(5,"Ben","Kinsley"));
			assertEquals(serviceFilm.getActors(), actors);
			
		}
	}


